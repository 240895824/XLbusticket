/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test1;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.ResultSet;  
import java.sql.Statement;  
import java.sql.SQLException; 
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
/**
 *
 * @author 许
 */

public class Test1 {
    public Test1(){
    TimerTask task1 = new TimerTask(){
            
            public void run(){
                
                
                Date date1=new Date();
                SimpleDateFormat sdf1=new SimpleDateFormat("yyyy.MM.dd");
                SimpleDateFormat sdf2=new SimpleDateFormat("HH:mm");
                
                String str=sdf1.format(date1);
                String str1=sdf2.format(date1);
                sql("DELETE FROM 例车表 WHERE 出发日期<'"+str+"'");
                sql("DELETE FROM 例车表 WHERE 出发日期='"+str+"'AND  出发时间<='"+str1+"'");
                
                }
        };
         Timer timer1=new Timer();
         timer1.schedule(task1,0,60000);
    
    
    }
     public static void main(String[] args) {
         new dl().setVisible(true);
        
        // TODO code application logic here
    }
 public  void sql(String sqll) {  
     Connection con = null;  
        Statement stmt = null;  
        ResultSet rs = null; 
        // 设置连接数据库的各个参数.  
        String connectionUrl = "jdbc:sqlserver://localhost:1433;"  
                + "databaseName=AdventureWorks;integratedSecurity=true;";  
          String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=xl;user=sa;password=123456";//以sa身份连接数据库 
  
        // 声明JDBC对象  
        
 try {  
            // 建立数据库连接.  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            con = DriverManager.getConnection(url);  
            stmt = con.createStatement();  
            stmt.executeUpdate(sqll); }
            catch (Exception e) {  
            e.printStackTrace();  
        }  
  
        finally {  
            if (rs != null)  
                try {  
                    rs.close(); //关闭查询结果集句柄 
                } catch (Exception e) {  
                }  
            if (stmt != null)  
                try {  
                    stmt.close();  //关闭语句句柄
                } catch (Exception e) {  
                }  
            if (con != null)  
                try {  
                    con.close();   //关闭数据库连接
                } catch (Exception e) {  
                }  
        }  
    
 
 
 }
  public  ResultSet sql1(String sqll) {  
        // 设置连接数据库的各个参数.  
        String connectionUrl = "jdbc:sqlserver://localhost:1433;"  
                + "databaseName=AdventureWorks;integratedSecurity=true;";  
          String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=xl;user=sa;password=123456";//以sa身份连接数据库 
  
        // 声明JDBC对象  
        Connection con1 = null;  
        Statement stmt1 = null;  
        ResultSet rs1 = null; 
 try {  
            // 建立数据库连接.  
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            con1 = DriverManager.getConnection(url);  
            stmt1 = con1.createStatement();  
            rs1 = stmt1.executeQuery(sqll);
            
 
 
 }
            catch (Exception e) {  
            e.printStackTrace();  
        }  
  
      
        
    return rs1;
  }
   
    
    /**
     * @param args the command line arguments
     */
   
    
}
